﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ilovecoffee
{
    class Program
    {
        static void Main(string[] args)
        {
            //Giacomo Bazan Production©. ITT Barsanti [barsanti.gov.it]
            /*The machine will count every kind of coffee, in the end the console
             will show you how many coffee, ginsengs or mojitos have been taken.
             I'll assign a variable to every article, every time you take each
             article, the counter will auto-increase his value.
             Conditional structures like WHILE, IF.
             */

            int x;
            int C = 1; //coffee
            int G = 2; //ginseng
            int M = 3; //mojito
            char QS;

            int SC = 0;
            int SG = 0;
            int SM = 0;


            int K = 0; //C's counter
            int J = 0; //G's counter
            int Y = 0; //M's counter


            bool S = (true);
            while (S == (true))
            {
                Console.Clear();
                Console.WriteLine("Welecome to the Coffee Machine, please select your drink...");
                Console.WriteLine("COFFEE'S CODE : 1 | PRICE 1 euros");
                Console.WriteLine("GINSENGS' CODE : 2 | PRICE 2 euros");
                Console.WriteLine("MOJITO'S CODE : 3 | PRICE 7 euros");

                x = Convert.ToInt32(Console.ReadLine());

                if (x == C) //if is coffee
                {
                    K = K + 1; //increase counter

                    SC = SC + 1;

                    Console.Clear();
                    Console.WriteLine("Thank you for shopping, do you want something else? <Y/N>");
                    QS = Convert.ToChar(Console.ReadLine()); //condition to redo the cicle, if the user write Y o N
                    if (QS == Convert.ToChar("Y") || QS == Convert.ToChar("y"))
                    {
                        S = (true);
                    }
                    else
                    {
                        S = (false);
                    }

                }
                else
                {
                    if (x == G)
                    {
                        J = J + 1;

                        SG = SG + 2;

                        Console.Clear();
                        Console.WriteLine("Thank you for shopping, do you want something else? <Y/N>");
                        QS = Convert.ToChar(Console.ReadLine()); //condition to redo the cicle, if the user write Y o N
                        if (QS == Convert.ToChar("Y") || QS == Convert.ToChar("y"))
                        {
                            S = (true);
                        }
                        else
                        {
                            S = (false);
                        }
                    }
                    else
                    {
                        if (x == M)
                        {
                            Y = Y + 1;

                            SM = SM + 7;

                        }
                        Console.Clear();
                        Console.WriteLine("Thank you for shopping, do you want something else? <Y/N>");
                        QS = Convert.ToChar(Console.ReadLine()); //condition to redo the cicle, if the user write Y o N
                        if (QS == Convert.ToChar("Y") || QS == Convert.ToChar("y"))
                        {
                            S = (true);
                        }
                        else
                        {
                            S = (false);
                        }
                    }

                }

            }

            Console.Clear();
            Console.WriteLine("You took" + " " + K + " " + "coffees" + " " + "and you have spent" + " " + SC + " euros"); //implementa i soldi
            Console.WriteLine("You took" + " " + J + " " + "ginsengs" + " " + "and you have spent" + " " + SG + " euros");
            Console.WriteLine("You took" + " " + Y + " " + "mojitos" + " " + "and you have spent" + " " + SM + " euros");

            Console.WriteLine("In total you spent" + " " + (SG + SC + SM) + " " + " euros");

            Console.WriteLine("Thank you for using the Coffee machine. Giacomo Bazan Production©. All rights reserved");

            Console.ReadKey();
        }
    }
}
